function checkAll( n, fldName ) {
    if (!fldName) {
        fldName = 'cb';
    }

    for (i=0; i < n; i++) {
        cb = eval( document.getElementById(fldName+i) );
        if (cb) {
            if (document.getElementById(fldName).checked){
                cb.checked = true;
            }
            else {
                cb.checked = false;
            }
        }
    }
    if (document.getElementById("cb").checked){
        document.getElementById("nb_cb").value=n;
    }
    else {
        document.getElementById("nb_cb").value=0;
    }
}

function decoche(b){
    document.getElementById("cb").checked=false;
    var n = parseInt(document.getElementById("nb_cb").value);
    if (b.checked){
        document.getElementById("nb_cb").value=n+1;
    }
    else {
        document.getElementById("nb_cb").value=n-1;
    }
}

function afficher_liste_classe(){
    var id_annee    = document.getElementById('id_annee').value;
    var parms='id_annee='+id_annee;
    var myAjax = new Ajax.Updater("liste_classe", "_liste.php", {
        method: 'post',
        parameters: parms
    });
    return false;
}