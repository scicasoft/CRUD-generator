<?php
require_once 'root.php';
include_once ROOT.'appl/layouts/tete.php';
?>
<div jmakiName="jmaki.revolver" style="width:800px; margin:auto; margin-top:100px"
     jmakiValue="{ items: [
     {label : 'Classes',
     imgSrc : '<?php echo ROOT ?>images/presentation/edt.png',
     href : '<?php echo ROOT ?>appl/classe/index.php'
     },
     {label : 'Eleves',
     imgSrc : '<?php echo ROOT ?>images/presentation/edt.png',
     href : '<?php echo ROOT ?>appl/etudiant/index.php'
     },
     {label : 'Professeurs',
     imgSrc : '<?php echo ROOT ?>images/presentation/edt.png',
     href : '<?php echo ROOT ?>appl/enseignant/index.php'
     },
     {label : 'Mati&egrave;res',
     imgSrc : '<?php echo ROOT ?>images/presentation/edt.png',
     href : '<?php echo ROOT ?>appl/uniteformation/index.php'
     },
     {label : 'Emploi du temps',
     imgSrc : '<?php echo ROOT ?>images/presentation/edt.png',
     href : '#'
     }
     ]}"></div>
<?php
include_once ROOT.'appl/layouts/pied.php';
?>