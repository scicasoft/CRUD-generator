<?php
require_once 'root.php';

/**
 * 11-06-09 11:44
 *
 * @author scicasoft
 */
class MaClasse {
    //put your code here
}

$current_dir = ROOT."mesclasses";
$dir = opendir($current_dir);

while ($file = readdir($dir))
{
    $long = strlen($file);
    $format = substr($file, $long-11, 11);
    if ($format=="_classe.php") require_once $file;
}
closedir($dir);
?>
