<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//FR" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <script src="<?php echo ROOT ?>resources/jmaki.js"></script>
    <script src="<?php echo ROOT ?>resources/wfactory.js"></script>
    <script src="<?php echo ROOT ?>javascripts/prototype.js"></script>
    <script src="<?php echo ROOT ?>javascripts/jquery-1.3.2.js"></script>
    <script src="<?php echo ROOT ?>javascripts/fonctions.js"></script>
    <?
    if (isset($javascripts)) foreach ($javascripts as $js) {
        echo "<script src='$js'></script>\n";
    }
    ?>
    <title>Gestion departement</title>
    <meta http-equiv="Content-Type" content="text/html; charset=unicode" />
    <link rel="stylesheet" type="text/css" href="<?php echo ROOT ?>stylesheets/styles.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo ROOT ?>stylesheets/menu_second.css" />
</head>
<body>
<div id="header">
    <div id="menu_tab">
        <!--<div class="left_menu_corner">
        </div>-->
        <ul class="menu">
            <li><a href="<?php echo ROOT ?>index.php" class="nav1">Home</a></li>
            <li class="divider"></li>
        </ul>
    </div>
    <h1><span class="heading_color"></span></h1>
</div>

<div id="container">
<div id="content">
<?php include_once ROOT.'appl/layouts/head.php'; ?>

<?= display_erreur() ?>