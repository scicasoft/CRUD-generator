<? if (defined("TITRE")) { ?>
<div id="toolbar-box">
    <div class="t">
        <div class="t">
            <div class="t"></div>
        </div>
    </div>
    <div class="m">
        <div class="toolbar" id="toolbar">
            <table class="toolbar"><tr>
<?php
if (isset($sous_menu)){
    foreach ($sous_menu as $sm){
        switch ($sm['type']){
            case "nouveau":
                echo "
                    <td class=\"button\">
                        <a href=\"".$sm['chemin']."\" class=\"toolbar\">
                            <span class=\"nouveau\" title=\"Nouveau\">
                            </span>
                            Nouveau
                        </a>
                    </td>";
                break;
            case "modifier":
                echo "
                    <td class=\"button\">
                        <a href=\"".$sm['chemin']."\" class=\"toolbar\" onclick=\"if (document.getElementById('nb_cb').value!='1'){alert('il faut cocher un enregistrement seulement'); return false;}else{ document.getElementById('type_form').value='modifier'; document.liste.submit();}\">
                            <span class=\"modifier\" title=\"Modifier\">
                            </span>
                            Modifier
                        </a>
                    </td>";
                break;
            case "supprimer":
                echo "
                    <td class=\"button\">
                        <a href=\"".$sm['chemin']."\" class=\"toolbar\" onclick=\"if (document.getElementById('nb_cb').value=='0'){alert('il faut cocher au moins un enregistrement'); return false;}else{ document.getElementById('type_form').value='supprimer'; document.liste.submit();}\">
                            <span class=\"supprimer\" title=\"Supprimer\">
                            </span>
                            Supprimer
                        </a>
                    </td>";
                break;
            case "annuler":
                echo "
                    <td class=\"button\">
                        <a href=\"".$sm['chemin']."\" class=\"toolbar\">
                            <span class=\"annuler\" title=\"Annuler\">
                            </span>
                            Annuler
                        </a>
                    </td>";
                break;
        }
    }
}
?>
            </tr></table>
        </div>
        <div class="header icon-48-addedit" style="background-image:url(' <?= FOND_TITRE ?>')">
            <?= TITRE ?>
        </div>

        <div class="clr"></div>
    </div>
    <div class="b">
        <div class="b">
            <div class="b"></div>
        </div>
    </div>
</div>
<? } ?>