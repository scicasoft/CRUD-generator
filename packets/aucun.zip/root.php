<?php
session_start();
define ("ROOT","");
require_once ROOT.'scripts/fonctions.php';
?>
