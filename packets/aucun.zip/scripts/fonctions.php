<?php
define(HOTE, "localhost");
define(USER, "root");
define(PASS, "");
define(BASE, "php_project_v2");

function execute_req($req){
    try{
        mysql_connect(HOTE, USER, PASS);
        $conn = new PDO('mysql:host='.HOTE.';dbname='.BASE, USER, PASS);
        $exe = $conn->prepare($req);
        $exe->execute();
        return $exe;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        die();
    }
}

function new_erreur($erreur){
    $_SESSION['erreur']=$erreur;
}

function display_erreur(){
    if (isset($_SESSION['erreur']) && $_SESSION['erreur']!=''){
        echo"<div id=\"message_erreur\">".$_SESSION['erreur']."</div>";
        $_SESSION['erreur']='';
    }
}

function resultat_requete_un($req){
    $reponse = execute_req($req);
    $donnees = mysql_fetch_row($reponse);
    return $donnees[0];
}

//verifie la validite d'une adresse email
function is_mail($mail){
    if (preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $mail))
    return TRUE;
    else
    return FALSE;
}

//verifie si une annee est bissextile
function bissex($an){
    if (is_positive_int($an))
    return ($an % 100<>0) && ($an % 4==0) || ($an % 100==0) && ($an % 400==0);
    else
    return FALSE;
}

//verifie la validite d'une date
function isdate($date){
    if (preg_match("#^\d{2}/\d{2}/\d{4}$#",$date))
    {
        $jour=substr($date, 1, 2);
        $mois=substr($date, 4, 2);
        $an=substr($date, 7, 4);
        if (($jour<1) || ($jour>31) || ($mois<1) || ($mois>12))
        $OK=FALSE;
        else
        {
            $liste = array('04','06','09','11');
            if (in_array($mois, $liste) && ($jour>30)) $OK=FALSE;
            if (($mois==2) && bissex($an) && ($jour>29)) $OK=FALSE;
            if (($mois==2) && !bissex($an) && ($jour>28)) $OK=FALSE;
        }
    }
    else
    $OK=FALSE;
    return $OK;
}

function securiser($chaine){
    $chaine = mysql_real_escape_string(htmlspecialchars($chaine));
    return $chaine;
}

function desecuriser($chaine){
    return stripcslashes(nl2br($chaine));
}

function display_req_result($tete, $req, $option) {
    echo "<table border='1' width='100%' id='tableau' cellspacing='0'>
    <thead>
        <tr>";
    for ($i = 0 ; $i < count($tete) ; $i++) {
        echo "<th>".$tete[$i]."</th>";
    }
    echo "</tr>
    </thead>
    <tbody>";
    $reponse = execute_req($req);
    while ($donnees = mysql_fetch_row($reponse)){
        echo "<tr>";
        for ($i = 0 ; $i < count($tete) ; $i++) {
            if (($option=='supprimer' || $option=='modifier') && ($i==count($tete)-1)){
                echo "<td align='center'>".$donnees[$i]."</td>";
            }
            else if (($option=='supprimer-modifier' || $option=='modifier-supprimer') && ($i>=count($tete)-2)){
                echo "<td align='center'>".$donnees[$i]."</td>";
            }
            else{
                echo "<td>".$donnees[$i]."</td>";
            }
        }
        echo "</tr>";
    }
    echo "</tbody>
</table>";
}

function afficher_bulletin($eleve, $classe=null, $semestre=1){
    $bs="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp";
    if ($classe==null) {
        $classe = resultat_requete_un("SELECT classe FROM `ClasseEtudiant ` WHERE etudiant='$eleve' ORDER BY `classe` LIMIT 0,1");
    }
    if ($semestre<>1 && $semestre<>2){
        $semestre = 1;
    }
    $res_classe = execute_req("SELECT * FROM `Classe` WHERE `idClasse`=$classe");
    $classe=mysql_fetch_array($res_classe);
    echo "<center>";
    echo "<table border='1'>";
    echo "<tr><td colspan='4'><b>Année Académique</b> : ".$classe['debutAnneeAcademique']." - ".($classe['debutAnneeAcademique']+1).""."$bs <b>Niveau :</b> ".$classe['niveau']."$bs <b> Cycle : </b>".$classe['cycle']."
                                    <br><br><h3>BULLETIN SEMESTRE $semestre</h3></td></tr>";
    $grpemat=execute_req("SELECT * FROM `GroupeMatiere`");
    while ($gprematiere=mysql_fetch_array($grpemat)){
        echo "    <tr>
                                    <td>Matières ".$gprematiere['libelle']."</td>
                                    <td>Coefficient</td>
                                    <td>Note/20</td>
                                    <td>Rang/??</td>
                                </tr>";
        $tcoef=0;
        $tpoint=0;
        $unitf=execute_req("SELECT `UniteFormation`.*, `MatiereFait`.`coef` FROM `MatiereFait`,`UniteFormation`,`Module`,`GroupeMatiere` WHERE `classe`='".$classe['idClasse']."' AND `GroupeMatiere`.`idGM`=`Module`.`groupeMatiere` AND `MatiereFait`.`uf`=`UniteFormation`.`idUf` AND `Module`.`CodeModule`=`UniteFormation`.`module` AND  `GroupeMatiere`.`idGM`='".$gprematiere['idGM']."' AND `semestre`=$semestre");
        while ($uform=mysql_fetch_array($unitf)){
            echo "<tr>
                                <td>".$uform['libelle']."</td>";
            $note=mysql_fetch_array(execute_req("SELECT * FROM `Note` WHERE `semestre`=$semestre AND `classe`='".$classe['idClasse']."' AND `etudiant`='".$_GET['eleve']."' AND `uf`='".$uform['idUf']."'"));
            if ($note['note']=='-1'){
                echo "<td><center>-</center></td><td><center>-</center></td>";
            }
            else{
                $tcoef+=(float)($uform['coef']);
                $tpoint+=(float)($uform['coef'])*(float)($note['note']);
                echo "<td><center>".$uform['coef']."</center></td><td><center>".$note['note']."</center></td>";
            }
            echo "<td>".rang_uf($eleve, $uform['idUf'], $classe['idClasse'], $semestre)."</td></tr>";
        }
        echo "<tr align='center'><td>TOTAL</td><td>$tcoef</td><td>$tpoint</td><td></td></tr>";
        if ($tcoef!=0){
            echo "<tr align='center'><td>MOYENNE</td><td></td><td>".($tpoint/$tcoef)."</td><td></td></tr>";
        }
        else{
            echo "<tr align='center'><td>MOYENNE</td><td></td><td>0</td><td></td></tr>";
        }
    }
    echo "</table><br>";
    echo "</center>";
}

function rang_uf($eleve, $uf, $classe, $semestre){
    $resultat = execute_req("select etudiant from Note where classe=$classe and semestre=$semestre and uf=$uf order by note desc");
    $i=0;
    $trouve = false;
    while (!trouve && $res=mysql_fetch_array($resultat)){
        $i+=1;
        $trouve = $res['etudiant']==$eleve;
    }
    if ($trouve){
        return $i;
    }
    else{
        return 0;
    }
}
?>